# VSCaptureMP
A C# .NET app, part of VSCapture software, to download or capture data from Philips Intellivue monitors. The software currently uses the UDP/IP protocol via LAN port or RS232 protocol via MIB port on the monitor for data logging. Requires Visual Studio 2015, .NET 4 or Xamarin Studio to compile.
